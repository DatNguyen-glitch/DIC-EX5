66-bit Comparator

1. Synthesize
./01_run_Synthesis

2. Convert to .sp
./Verilog2Spice
python3 pin_adder_VSS_VDD.py

3. Setup the hspice env

4. Minimize the delay
