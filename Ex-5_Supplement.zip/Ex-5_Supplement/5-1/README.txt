2x2 Maxpooling

1. Synthesize (compile_ultra)
./01_run_Synthesis

2. Find worst case delay(show in report)

3. Convert to .sp
./Verilog2Spice
python3 pin_adder_VSS_VDD.py

4. EDP-voltage figure
